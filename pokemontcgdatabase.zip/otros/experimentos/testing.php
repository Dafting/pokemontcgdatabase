<?php

//show 100 decimals of pi
echo number_format(pi(), 50);

