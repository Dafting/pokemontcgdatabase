<?php

function error401() {
    header("HTTP/1.0 401 Unauthorized");
    echo '<h1>401 Unauthorized</h1>';
    echo '<p>You don\'t have permission to access this page on this server.</p>';
    echo '<hr>';
    echo '<address>';
    echo '  <a href="http://' . $_SERVER['SERVER_NAME'] . '">' . $_SERVER['SERVER_NAME'] . '</a><br>';
    echo '</address>';
}

function error403() {
    header("HTTP/1.0 403 Forbidden");
    echo '<h1>403 Forbidden</h1>';
    echo '<p>You don\'t have permission to access this page on this server.</p>';
    echo '<hr>';
    echo '<address>';
    echo '  <a href="http://' . $_SERVER['SERVER_NAME'] . '">' . $_SERVER['SERVER_NAME'] . '</a><br>';
    echo '</address>';
}

function error404() {
    header("HTTP/1.0 404 Not Found");
    echo '<h1>404 Not Found</h1>';
    echo '<p>The requested URL was not found on this server.</p>';
    echo '<hr>';
    echo '<address>';
    echo '  <a href="http://' . $_SERVER['SERVER_NAME'] . '">' . $_SERVER['SERVER_NAME'] . '</a><br>';
    echo '</address>';
}
