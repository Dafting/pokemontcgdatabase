<?php
    
    include_once('\libs\Smarty.class.php');
    $smarty = new Smarty();

    function showIndex($smarty) {
        $smarty->display('index.tpl');
    }

    function showLogin($smarty) {
        $smarty->display('login.tpl');
    }
    