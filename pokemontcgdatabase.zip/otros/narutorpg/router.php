<?php

    require_once ('\functions\errorCodes.php');
    require_once ('\index.php');

    // lee la acción
    if (!empty($_GET['action'])) {
        $action = $_GET['action'];
    } else {
        $action = 'home'; // acción por defecto si no envían
    }

    // parsea la accion Ej: suma/1/2 --> ['suma', 1, 2]
    $params = explode('/', $action);

    // determina que camino seguir según la acción
    switch ($params[0]) {
        case 'home': 
            echo ("ping!");
            break;
        case 'login':
            if (isset($params[1])) {
                showHome($smarty);
                break;
            }
            showLogin($smarty);
            break;
        default: 
            error404();
            break;
    }
