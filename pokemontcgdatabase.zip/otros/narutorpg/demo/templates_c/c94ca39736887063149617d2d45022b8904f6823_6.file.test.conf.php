<?php /* Smarty version 3.1.39, created on 2021-10-13 05:11:28
         compiled from 'C:\xampp\htdocs\tpe_web2grupo13\demo\configs\test.conf' */ ?>
<?php
/* Smarty version 3.1.39, created on 2021-10-13 05:11:28
  from 'C:\xampp\htdocs\tpe_web2grupo13\demo\configs\test.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61664e60ed4250_93552451',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c94ca39736887063149617d2d45022b8904f6823' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tpe_web2grupo13\\demo\\configs\\test.conf',
      1 => 1613599071,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61664e60ed4250_93552451 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
