<?php
/* Smarty version 3.1.39, created on 2021-10-13 05:11:29
  from 'C:\xampp\htdocs\tpe_web2grupo13\demo\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61664e610a72f8_36958129',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bbb331c6790e3b1a2844f0975c313a853e58fed8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tpe_web2grupo13\\demo\\templates\\footer.tpl',
      1 => 1613599071,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61664e610a72f8_36958129 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '176460546961664e610a5591_09835506';
?>
</BODY>
</HTML>
<?php }
}
