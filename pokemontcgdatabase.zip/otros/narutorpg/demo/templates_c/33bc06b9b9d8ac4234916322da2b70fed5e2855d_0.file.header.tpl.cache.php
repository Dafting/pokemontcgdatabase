<?php
/* Smarty version 3.1.39, created on 2021-10-13 05:11:28
  from 'C:\xampp\htdocs\tpe_web2grupo13\demo\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61664e60f40010_00983834',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '33bc06b9b9d8ac4234916322da2b70fed5e2855d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tpe_web2grupo13\\demo\\templates\\header.tpl',
      1 => 1613599071,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61664e60f40010_00983834 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '44528711061664e60f3bba7_73767513';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:44528711061664e60f3bba7_73767513%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:44528711061664e60f3bba7_73767513%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
