//post ajax request to login.php

//button add event listener
let botonLogin = document.querySelector("#loginForm");

//Asignacion de evento
botonLogin.addEventListener("click", login);

//post ajax request to login.php
function login(e) {
    e.preventDefault();
    let form = document.querySelector("#loginForm");
    let formData = new FormData(form);
    let url = "login";
    let request = new XMLHttpRequest();
    request.open("POST", url, true);
    request.onload = function () {
        if (request.status == 200) {
            let response = request.responseText;
            if (response == "true") {
                window.location.href = "index.php";
            } else {
                alert("Usuario o contraseña incorrectos");
            }
        } else {
            alert("Error en la peticion");
        }
    }
    request.send(formData);
}


//function login() {
//    let username = document.getElementById("username").value;
//    let password = document.getElementById("password").value;
//    let data = {
//        username: username,
//        password: password
//    };
//    $.ajax({
//        type: "POST",
//        url: "login/" + username, 
//        data: data,
//        success: function(response) {
//            if (response == "success") {
//                window.location.href = "home";
//            } else {
//                document.getElementById("error").innerHTML = response;
//            }
//        }
//    });
//}