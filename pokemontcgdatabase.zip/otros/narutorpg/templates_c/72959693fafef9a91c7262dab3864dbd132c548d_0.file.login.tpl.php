<?php
/* Smarty version 3.1.39, created on 2021-10-23 05:02:23
  from 'C:\xampp\htdocs\narutorpg\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61737b3f421ef7_87448364',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '72959693fafef9a91c7262dab3864dbd132c548d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\narutorpg\\templates\\login.tpl',
      1 => 1634958141,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61737b3f421ef7_87448364 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="loginbox">
    <h1>Login Here</h1>
    <form action="login" method="post">
        <p>Username</p>
        <input id="username" type="text" name="username" placeholder="Enter Username">
        <p>Password</p>
        <input id="password" type="password" name="password" placeholder="Enter Password">
        <input id="loginForm" type="button" name="submit" value="Login">
    </form>
</div>

<h1 id="error"></h1>

<?php echo '<script'; ?>
 src="js/login.js"><?php echo '</script'; ?>
><?php }
}
